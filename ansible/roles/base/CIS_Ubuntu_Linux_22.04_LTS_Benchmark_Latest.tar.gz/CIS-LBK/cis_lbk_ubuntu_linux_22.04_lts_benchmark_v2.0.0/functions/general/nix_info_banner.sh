#!/usr/bin/env bash

BANR()
{
	echo ""
	echo ""
	echo "     ######################################################## "
	echo "     #  CIS Linux Build Kit for Ubuntu Linux 22.04 LTS Benchmark v2.0.0      "
	echo "     #  This Linux Build Kit works in conjunction with the  "
	echo "     #  CIS Ubuntu Linux 22.04 LTS Benchmark v2.0.0         "
	echo "     #  This script is the property of:                     "
	echo "     #  Center for Internet Security (CIS)                  "
	echo "     ######################################################## "
	echo ""
	echo ""
}
# End of print banner to Screen