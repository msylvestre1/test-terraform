#!/usr/bin/env bash

#
# CIS Build Kit test script
#
# Name              Date        Description
# ------------------------------------------------------------------------------------------------
# J. Brown         	04/28/23	V1 Simplified buildkit test script
# J. Brown			02/13/24	Added ability to test within Git repo structure

load_functions(){
	for func in $1; do
		[ -e "$func" ] || break
		. "$func"
	done
}

testrec()
{
	$REC
	output_code="$?"

	test_output
	return
}

test_output()
{
	case "$output_code" in
		101)
			echo "*****************************************************************"
			echo " - $RN - $RNA -"
			echo " - PASSED - Remediation not required"
			echo "*****************************************************************"
			;;
		102)
			echo "*****************************************************************"
			echo " - $RN - $RNA -"
			echo " - FAILED - Recommendation failed remediation"
			echo "*****************************************************************"
			;;
		103)
			echo "*****************************************************************"
			echo " - $RN - $RNA -"
			echo " - REMEDIATED - Recommendation successfully remediated"
			echo "*****************************************************************"
			;;
		104)
			echo "*****************************************************************"
			echo " - $RN - $RNA -"
			echo " - N/A - Recommendation is non applicable"
			echo "*****************************************************************"
			;;
		105)
			echo "*****************************************************************"
			echo " - $RN - $RNA -"
			echo " - EXCLUDED - Recommendation on the excluded list"
			echo "*****************************************************************"
			;;
		106)
			echo "*****************************************************************"
			echo " - $RN - $RNA -"
			echo " - MANUAL - Recommendation needs to be remediated manually"
			echo "*****************************************************************"
			;;
		107)
			echo "*****************************************************************"
			echo " - $RN - $RNA -"
			echo " - SKIPPED - Recommendation not in selected profile"
			echo "*****************************************************************"
			;;
		201)
			echo "*****************************************************************"
			echo " - $RN - $RNA -"
			echo " - REMEDIATED - Recommendation remediation run"
			echo "*****************************************************************"
			;;
		*)
			echo "*****************************************************************"
			echo " - $RN - $RNA -"
			echo " - ERROR - Output code not set"
			echo "*****************************************************************"
			;;
	esac
	output_code=""
}

# Ensure script is executed in bash
if [ ! "$BASH_VERSION" ] ; then
	exec /bin/bash "$0" "$@"
fi

echo -e "
\n\t########################################################\n\n
\t\t\tLinux Build Kit Test Script\n\n
\t########################################################\n"

# Set global variables
BDIR="$(dirname "$(readlink -f "$0")")"
DTG=$(date +%m_%d_%Y_%H%M)

# Determine scripts structure
if [ -e "$BDIR/functions" ]; then
	echo "Using Build Kit directory structure"
	script_source="buildkit"
else
	echo "Using Git repo directory structure"
	script_source="git_repo"
fi

# Make logs
if [ "$script_source" = "buildkit" ]; then
	LOGDIR=$BDIR/logs/$DTG
	mkdir -p $LOGDIR
	LOG=$LOGDIR/CIS-LBK_verbose.log
	ELOG=$LOGDIR/CIS-LBK_error.log
else
	LOG=/dev/null
	ELOG=/dev/null
fi

# Load functions (Order matters)
if [ "$script_source" = "buildkit" ]; then
	load_functions "$BDIR/functions/general/*.sh"
	load_functions "$BDIR/functions/recommendations/**/*.sh"
else
	load_functions "$BDIR/0-General/*.sh"
	load_functions "$BDIR/1-Initial_Setup/*.sh"
	load_functions "$BDIR/2-Services/*.sh"
	load_functions "$BDIR/3-Network_Configuration/*.sh"
	load_functions "$BDIR/4-Logging_and_Auditing/*.sh"
	load_functions "$BDIR/5-Access_Authentication_and_Authorization/*.sh"
	load_functions "$BDIR/6-System_Maintenance/*.sh"
fi

# # Recommedations This is where a test begins.

## Paste the item or items you'd like to test below from the normal Build Kit script

RN="1.8.2"
RNA="Ensure GDM login banner is configured"
profile="L1S L1W"
REC="authentication_singleuser_mode"
# FSN references the function script name
FSN="nix_authentication_singleuser_mode.sh"
testrec

# End of recommendations
echo "Done"